import os
import numpy as np
import  requests
from PIL import Image
import json


img = Image.open('images/mug.jpg')
sample_img = img.convert('RGB')
resized_img = sample_img.resize((224, 224), Image.BILINEAR)
resized = np.array(resized_img)
scaled = (resized / 127.5) - 1
ordered = np.transpose(scaled, (2, 0, 1))
ordered = ordered.tolist()
#print(ordered)


#densenet
ri1={"name":"INPUT__0","shape":[1,3,224,224],"datatype":"FP32","data":list(ordered)}

ro1={"name":"OUTPUT__0","shape":[1,2048],"datatype":"FP32"}

inference_request={"id":"1","inputs":[ri1],"outputs":[ro1]}

r = json.dumps(inference_request)


response = requests.post("http://localhost:8000/v2/models/resnet/versions/1/infer", data=r)
response_json = json.loads(response.text)
#with open('resnet_output.json', 'w') as json_file:
#    json_file.write(response_json)

print(response_json['outputs'][0]['data'])
vectors = response_json['outputs'][0]['data']
print(type(vectors))
