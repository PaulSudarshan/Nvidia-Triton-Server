import requests
import json
ri1={"name":"INPUT0","shape":[1,16],"datatype":"INT32","data":[[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]]}

ri2={"name":"INPUT1","shape":[1,16],"datatype":"INT32","data":[[-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]]}

ro1={"name":"OUTPUT0","shape":[1,16],"datatype":"INT32"}
ro2={"name":"OUTPUT1","shape":[1,16],"datatype":"INT32"}

inference_request={"id":"1","inputs":[ri1,ri2],"outputs":[ro1,ro2]}

r = json.dumps(inference_request)


response = requests.post("http://localhost:8000/v2/models/simple/versions/1/infer", data=r)

print(response.text) #TEXT/HTML
print(response.status_code, response.reason) #HTTP
