import json
import zlib
import numpy as np
import requests
from transformers import AutoTokenizer, PreTrainedTokenizer, TensorType

#from transformer_deploy.benchmarks.utils import print_timings, setup_logging, track_infer_time

url = "http://127.0.0.1:8000/v2/models/distil_roberta/versions/1/infer"
tokenizer: PreTrainedTokenizer = AutoTokenizer.from_pretrained('sentence-transformers/paraphrase-distilroberta-base-v2')

def get_embeddings(sentence):
    tokens = tokenizer(sentence, padding=True, truncation=True, return_tensors='pt')

    # https://github.com/triton-inference-server/server/blob/main/docs/protocol/extension_classification.md

    message = {
        "id": "42",
        "inputs": [
            {
                "name": "input_ids",
                "shape": tokens["input_ids"].shape,
                "datatype": "INT64",
                "data": tokens["input_ids"].tolist(),
            },
            {
                "name": "attention_mask",
                "shape": tokens["attention_mask"].shape,
                "datatype": "INT64",
                "data": tokens["attention_mask"].tolist(),
            },
        ],
        "outputs": [
            {
                "name": "852",
                "parameters": {"binary_data": False},
            }
        ],
    }

    r = json.dumps(message)

    response = requests.post(url, data=r)

    response_json = json.loads(response.text)
    #print(response_json)
    # print(type(response_json))
    # print(response_json.keys())
    embeds = response_json['outputs'][0]['data']
    return embeds

# sentences = ['This is an example sentence', 'Each sentence is converted']

# embeddings=[]
# for sen in sentences:
#     embeddings.append(get_embeddings(sen))

# print(len(embeddings))
# print(len(embeddings[0]))

from flask import Flask, jsonify, request
app = Flask(__name__)

@app.route('/embeds', methods=['GET'])
def search():
    args = request.args
    string = args.get("sentence")
    embeddings = get_embeddings(string)
    data= {'string' : string,'embeddings' : embeddings}
    return jsonify(data)


if __name__ == '__main__':
    app.run(host='0.0.0.0',port='5000',debug=True)
