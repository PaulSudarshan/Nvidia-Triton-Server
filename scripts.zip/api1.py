from flask import Flask, jsonify, request
from search import run_search
app = Flask(__name__)
  
  
@app.route('/search', methods=['GET'])
def search():
    if(request.method == 'GET'):
        data = run_search()
        return jsonify(data)
  
  
if __name__ == '__main__':
    app.run(host='0.0.0.0',port='5000',debug=True)

