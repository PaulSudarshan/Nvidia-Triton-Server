import os
import  requests
import json
import glob
import time

r={"img_name":["kitti_005/0000000021.png","kitti_011/0000000016.png"],"no_of_matches":4}
print(r)
response = requests.post("http://ec2-54-90-83-77.compute-1.amazonaws.com:5000/search_id", data=r)
response_json = json.loads(response.text)
print(response_json)



   

