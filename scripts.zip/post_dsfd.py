import os
import numpy as np
import  requests
from PIL import Image
import json
import torch
from torchvision.ops import nms
import cv2



def filter_boxes(boxes: torch.Tensor):
    """Performs NMS and score thresholding

    Args:
        boxes (torch.Tensor): shape [N, B, 5] with (xmin, ymin, xmax, ymax, score)
    Returns:
        list: N np.ndarray of shape [B, 5]
    """
    final_output = []
    # boxes = np.array(boxes)
    boxes = torch.reshape(boxes,(1,62544,5))
    # boxes=list(boxes)
    for i in range(len(boxes)):
        
        scores = boxes[i, :,  4]
        keep_idx = scores >= confidence_threshold
        boxes_ = boxes[i, keep_idx, :-1]
        scores = scores[keep_idx]
        if scores.dim() == 0:
            final_output.append(torch.empty(0, 5))
            continue
        keep_idx = nms(boxes_, scores, nms_iou_threshold)
        scores = scores[keep_idx].view(-1, 1)
        boxes_ = boxes_[keep_idx].view(-1, 4)
        output = torch.cat((boxes_, scores), dim=-1)
        final_output.append(output)
    return final_output

def scale_boxes(imshape, boxes):
    height, width = imshape
    boxes[:, [0, 2]] *= width
    boxes[:, [1, 3]] *= height
    return boxes

def validate_detections(boxes):
    for box in boxes:
        assert np.all(box[:, 4] <= 1) and np.all(box[:, 4] >= 0),\
            f"Confidence values not valid: {box}"

def resize(image, shrink: float):
        max_resolution=1080
        if max_resolution is None and shrink == 1:
            return image
        height, width = image.shape[2:4]
        shrink_factor = max_resolution / max((height, width))
        if shrink_factor <= shrink:
            shrink = shrink_factor
        size = (732,1024)
        image = torch.nn.functional.interpolate(image, size=size)
        return image

def _pre_process(image: np.ndarray, shrink: float) -> torch.Tensor:
        """Takes N RGB image and performs and returns a set of bounding boxes as
            detections
        Args:
            image (np.ndarray): shape [N, height, width, 3]
        Returns:
            torch.Tensor: shape [N, 3, height, width]
        """
        assert image.dtype == np.uint8
        mean = np.array([123, 117, 104], dtype=np.float32).reshape(1, 1, 1, 3)
        height, width = image.shape[1:3]
        image = image.astype(np.float32) - mean
        image = np.moveaxis(image, -1, 1)
        image = torch.from_numpy(image)
        image = resize(image, shrink)
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        image = image.to(device)

        image = image.to(device)
        return image

def predict_boxes(img_path):
    image = cv2.imread(img_path)
    shrink=1
    preprocessed_image = _pre_process(image, shrink)
    preprocessed_image = preprocessed_image.tolist()
    
    print('Shape of input image : ',image.shape)
    print('Shape of Preprocessed input image : ',np.array(preprocessed_image).shape)
    ri1={"name":"input.1","shape":[3,732,1024],"datatype":"FP32","data":list(preprocessed_image)}

    ro1={"name":"2626","shape":[1,62544,5],"datatype":"FP32"}


    inference_request={"id":"1","inputs":[ri1],"outputs":[ro1]}

    r = json.dumps(inference_request)


    response = requests.post("http://localhost:8000/v2/models/dsfd_onnx/versions/1/infer", data=r)
    response_json = json.loads(response.text)
    boxes = np.array(response_json['outputs'][0]['data'])
    boxes = np.reshape(boxes,(1,1,62544,5))
    boxes = torch.tensor(boxes)

    print(boxes.shape)

    boxes = filter_boxes(boxes)
    clip_boxes=False
    if clip_boxes:
        boxes = [box.clamp(0, 1) for box in boxes]
    height, width, c = image.shape
    boxes = [scale_boxes((height, width), box).cpu().numpy() for box in boxes]
    validate_detections(boxes)

    return boxes
def draw_faces(im, bboxes):
    for bbox in bboxes:
        x0, y0, x1, y1,cnf = [int(_) for _ in bbox]
        cv2.rectangle(im, (x0, y0), (x1, y1), (0, 0, 255), 2)
        #Random noise:
        #dummy_img = np.random.randn(im.shape[0],im.shape[1],im.shape[2])
        #im[y0:y1, x0:x1, :] = dummy_img[y0:y1, x0:x1, :]
        h=y1-y0
        w=x1-x0
        roi=im[y0:y0+h,x0:x0+w]
        circen = ((x0 + x1) // 2, (y0 + y1) // 2)
        mask_im = np.zeros(im.shape, dtype='uint8')
        cv2.ellipse(mask_im,circen,(int(w/2),int(h/2)),0,0,360,(255,255,255),-1)
        blur_im = cv2.GaussianBlur(im, (91, 91), 0)
        im = np.where(mask_im > 0, blur_im, im)
    cv2.imwrite('images/result_blur.jpg',im)

confidence_threshold=0.5
nms_iou_threshold=0.3

img_path = 'images/faces.png'
boxes = predict_boxes(img_path)
boxes = np.array(boxes)
im = cv2.imread(img_path)
draw_faces(im,boxes[0])

print(type(boxes))
print(boxes.shape)
print(boxes)

