import os
import numpy as np
import  requests
from PIL import Image
import json
import glob
import time
from tqdm import tqdm
from pymilvus import connections
import pymilvus
from pymilvus import CollectionSchema, FieldSchema, DataType, Collection,utility
import redis
import matplotlib.pyplot as plt

#print(pymilvus.list_collections())
#print(collection.primary_field)
#print(utility.has_collection(collection_name))

def generate_response(img_path,):
    img = Image.open(img_path)
    sample_img = img.convert('RGB')
    resized_img = sample_img.resize((224, 224), Image.BILINEAR)
    resized = np.array(resized_img)
    scaled = (resized / 127.5) - 1
    ordered = np.transpose(scaled, (2, 0, 1))
    ordered = ordered.tolist()

    #resnet
    ri1={"name":"INPUT__0","shape":[1,3,224,224],"datatype":"FP32","data":list(ordered)}

    ro1={"name":"OUTPUT__0","shape":[1,2048],"datatype":"FP32"}

    inference_request={"id":"1","inputs":[ri1],"outputs":[ro1]}

    r = json.dumps(inference_request)

    response = requests.post("http://localhost:8000/v2/models/resnet/versions/1/infer", data=r)
    response_json = json.loads(response.text)
    vectors = response_json['outputs'][0]['data']
    vector_np = np.array(vectors)
    vector_float = vector_np.astype('float32').tolist()
    vector_float = [vector_float]
    #entities = [vector_float]
    return vector_float



def run_search():

    connections.connect(host="127.0.0.1", port=19530)
    red = redis.Redis(host = '127.0.0.1', port=6379, db=0)

    collection_name = "trial"
    collection = Collection(collection_name)      # Get an existing collection.
    collection.load()

    print()
    random_ids = [int(red.randomkey()) for x in range(1)]
    print(random_ids)
    search_images = [x.decode("utf-8") for x in red.mget(random_ids)]
    print(random_ids, search_images)
    final_result=[]
    lim = 4
    for query_image in search_images:
        query_vectors = generate_response(query_image)
        search_params = {"metric_type": "L2", "params": {"nprobe": 32}}
        start = time.time()
        results = collection.search(query_vectors, "vector", param=search_params, limit=lim, expr=None)
        final_result.append(results)
        end = time.time() - start

        print("Search took a total of: ", end)

    #print('SEARCH IMAGES :',search_images)
    #for i in final_result[0][0]:
    #    print(i.id)
    print()
    api_res = []
    
    for x in range(len(final_result)): 
        query_file = search_images[x]
        print('Query :: ',query_file)

        for y in range(len(final_result[x])):
            #for z in range(lim):
            res = final_result[x][y]
            #print(res.id)
            result_files = [red.get(i.id).decode('utf-8') for i in res]
            result={}
            result['query_image'] = query_file  
            result['matched_files'] = result_files

            print("Matched Files : ",result_files)
            distances = [i.distance for i in res]
            result['distances'] = distances
            print("Distances : ", distances)
        api_res.append(result)
        print()
    return api_res
run_search()
