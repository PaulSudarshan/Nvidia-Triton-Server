import os
import requests
from minio import Minio


client = Minio(
        "onstagedatadrive1.azurewebsites.net",
        access_key="onstagedatadrive1",
        secret_key="nWnpkgRNAdpyd0NP0StoEXcHQdhJDBWDDdfCLcDcgWq1K5ysjQlhYhSHMXEmuNH562DZpXPuo16CgenHTNyPxA=="
    )

all_files = []
objects = client.list_objects('data-service')
print([obj.object_name for obj in objects])

