import os
import numpy as np
import  requests
from PIL import Image
import json


img = Image.open('images/test.jpg')
sample_img = img.convert('RGB')
resized_img = sample_img.resize((640, 640), Image.BILINEAR)
resized = np.array(resized_img)
scaled = (resized / 127.5) - 1
ordered = np.transpose(scaled, (2, 0, 1))
ordered = ordered.tolist()
#print(ordered)


#densenet
ri1={"name":"images","shape":[3,640,640],"datatype":"FP32","data":list(ordered)}

#ro1=[{"name":"OUTPUT__0","shape":[1,2048],"datatype":"FP32"}]
ro1=[{"name":"3191","datatype":"FP32","shape":[-1]},{"name":"3192","datatype":"INT64","shape":[-1]},{"name":"3680","datatype":"FP32","shape":[-1,4]},{"name":"3698","datatype":"FP32","shape":[-1,-1,3]},{"name":"end_scores.7","datatype":"FP32","shape":[-1,-1]}]


inference_request={"id":"1","inputs":[ri1],"outputs":ro1}

r = json.dumps(inference_request)


response = requests.post("http://localhost:8000/v2/models/key_point_onnx/versions/1/infer", data=r)
response_json = json.loads(response.text)
#print(response_json)
#with open('resnet_output.json', 'w') as json_file:
#    json_file.write(response_json)

#print(response_json['outputs'][0]['data'][0])
print(response_json)
#for j in range(0,len(response_json['outputs'])):
#for i in range(0,len(response_json['outputs'])):
 #   print(response_json['outputs'][i]['data'].type())

#vectors = response_json['outputs'][0]['data']
#print(type(vectors))
                       
