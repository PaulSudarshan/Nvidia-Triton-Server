import pandas as pd


df = pd.read_csv('milvus_path.csv')
#print(df['id'][0])
#search_id = 
row = df[df['path']=='kitti/0000000004.png']
a = row['path'].item()
print(a)
print(row['vector'].item())
print(df.head(2))

