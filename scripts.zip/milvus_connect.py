#Connectings to Milvus and Redis

from pymilvus import connections, utility, Collection
import redis

connections.connect(host="127.0.0.1", port=19530)
red = redis.Redis(host = '127.0.0.1', port=6379, db=0)

print(utility.list_collections())
collection_name = 'trial'
print(utility.has_collection(collection_name))
collection = Collection(collection_name)      # Get an existing collection.
collection.load()
random_ids = [int(red.randomkey()) for x in range(3)]
print(random_ids)
search_images = [x.decode("utf-8") for x in red.mget(random_ids)]
print(search_images)
