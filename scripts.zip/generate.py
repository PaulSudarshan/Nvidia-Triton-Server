import os
import numpy as np
import  requests
from PIL import Image
import json
import glob
import time
from tqdm import tqdm
from pymilvus import connections
from pymilvus import CollectionSchema, FieldSchema, DataType, Collection,utility
import redis

connections.connect(host="127.0.0.1", port=19530)
red = redis.Redis(host = '127.0.0.1', port=6379, db=0)
red.flushdb()


collection_name = "image_similarity_search"
utility.drop_collection(collection_name)
dim = 2048
default_fields = [
    FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
    FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=dim)
]
default_schema = CollectionSchema(fields=default_fields, description="Image test collection")

collection = Collection(name=collection_name, schema=default_schema)

# Create IVF_SQ8 index to the  collection
default_index = {"index_type": "IVF_SQ8", "params": {"nlist": 2048}, "metric_type": "L2"}
collection.create_index(field_name="vector", index_params=default_index)
collection.load()

def generate_response(img_path,):
    img = Image.open(img_path)
    sample_img = img.convert('RGB')
    resized_img = sample_img.resize((224, 224), Image.BILINEAR)
    resized = np.array(resized_img)
    scaled = (resized / 127.5) - 1
    ordered = np.transpose(scaled, (2, 0, 1))
    ordered = ordered.tolist()

    #resnet
    ri1={"name":"INPUT__0","shape":[1,3,224,224],"datatype":"FP32","data":list(ordered)}

    ro1={"name":"OUTPUT__0","shape":[1,2048],"datatype":"FP32"}

    inference_request={"id":"1","inputs":[ri1],"outputs":[ro1]}

    r = json.dumps(inference_request)

    response = requests.post("http://localhost:8000/v2/models/resnet/versions/1/infer", data=r)
    response_json = json.loads(response.text)
    vectors = response_json['outputs'][0]['data']
    vector_np = np.array(vectors)
    vector_float = vector_np.astype('float32').tolist()
    #vector_float = [vector_float]
    #entities = [vector_float]
    return vector_float


data_dir = "./VOCdevkit/VOC2012" # You can replace this to your local directory of image folders
pattern = "*.jpg"

subfolders = [os.path.join(data_dir, x) for x in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, x))]
# print(subfolders)
steps = len(subfolders)
step = 1
start = time.time()
entities=[]
for sub_dir in subfolders:
    img_pattern = os.path.join(sub_dir, pattern)
    paths = glob.glob(img_pattern)
    for img_path in tqdm(paths[:30]):
        entities.append(generate_response(img_path))

    mr = collection.insert([entities])
    ids = mr.primary_keys
    
    for x in range(len(ids)):
        red.set(str(ids[x]), paths[x])
        
            
    print("Inserting progress: " + str(step) + "/" + str(steps))
    step += 1
end = time.time() - start
print("Generating Features took a total of: ", end)

