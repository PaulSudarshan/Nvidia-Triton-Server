import os
import numpy as np
import  requests
from PIL import Image
import json


img = Image.open('images/mug.jpg')
sample_img = img.convert('RGB')
resized_img = sample_img.resize((640, 640), Image.BILINEAR)
resized = np.array(resized_img)
scaled = (resized / 127.5) - 1
ordered = np.transpose(scaled, (2, 0, 1))
ordered = ordered.tolist()
#print(ordered)


#densenet
ri1={"name":"images","shape":[3,640,640],"datatype":"FP32","data":list(ordered)}

ro1={"name":"output","shape":[1,25200,21],"datatype":"FP32"}

inference_request={"id":"1","inputs":[ri1],"outputs":[ro1]}

r = json.dumps(inference_request)


response = requests.post("http://localhost:8000/v2/models/yolov5_onnx/versions/1/infer", data=r)
response_json = json.loads(response.text)
#with open('resnet_output.json', 'w') as json_file:
#    json_file.write(response_json)

#print(response.text)
print(response_json['outputs'][0]['data'])
vectors = response_json['outputs'][0]['data']
print(type(vectors))

